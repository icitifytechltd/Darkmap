__version__ = "2.0"
__author__ = "ICITIFY TECH"
from .darkmap import launch
